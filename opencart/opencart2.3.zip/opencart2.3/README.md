# Support 
Opencart 2.3.x
# Install
Copy all directories to merge your `admin` and `catalog` directory  
# Setting
- In admin panel, select `Extentsion`, choose `Payments`, you will see Dhpay.
- Click install
- Then click Edit, input you MerchantId, Privacy Key,Payment title and others information

