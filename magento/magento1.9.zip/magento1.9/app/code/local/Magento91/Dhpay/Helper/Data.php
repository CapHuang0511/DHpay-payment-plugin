<?php
/**
 * E: chinadragon@hotmail.com
 * W:www.magento.con
 */
class Magento91_Dhpay_Helper_Data extends Mage_Core_Helper_Abstract
{

}
