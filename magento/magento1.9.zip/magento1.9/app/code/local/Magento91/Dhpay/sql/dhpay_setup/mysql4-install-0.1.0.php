<?php
/**
 * E: chinadragon@hotmail.com
 * W:www.magento.con
 */


$installer = $this;
